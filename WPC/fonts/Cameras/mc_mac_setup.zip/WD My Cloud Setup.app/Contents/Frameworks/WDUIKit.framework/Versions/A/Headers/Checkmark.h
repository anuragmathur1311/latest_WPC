//
//  Checkmark.h
//  RoundTransparentWindow
//
//  Created by Clark Jackson on 12/31/08.
//  Copyright 2008 Western Digital. All rights reserved.
//


@interface Checkmark : NSView {

}

@end
