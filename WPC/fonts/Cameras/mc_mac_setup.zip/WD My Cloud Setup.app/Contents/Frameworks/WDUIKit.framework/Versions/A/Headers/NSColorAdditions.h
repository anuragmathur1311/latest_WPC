#import <Cocoa/Cocoa.h>

@interface NSColor(CustomAlternatingRowBackgroundColors)

+ (NSArray *)controlAlternatingRowBackgroundColors;

@end
