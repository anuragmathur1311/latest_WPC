/*
File:		WDHelpView.h

Description: 	This is the header file for the OB01View class, which handles the drawing of the window content.
*/


@interface WDHelpView : NSView
{

}

@end
