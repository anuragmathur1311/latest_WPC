
@interface WDWindowButtonsControl : NSView 
{
    NSImage *_currentImg;
}

@end
