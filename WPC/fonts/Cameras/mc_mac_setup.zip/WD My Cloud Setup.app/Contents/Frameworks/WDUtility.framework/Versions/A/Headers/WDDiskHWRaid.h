//
//  WDDiskHWRaid.h
//  WDUtility
//
//  Created by Robert (bobhahn@mac.com) Hahn on 12/13/13.
//
//

#import <Foundation/Foundation.h>
#import "WDDisk.h"

@interface WDDiskHWRaid : WDDisk
{
}

@end
